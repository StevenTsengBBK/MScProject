python3 ResNeStGPU.py --dataset imagenet --model resnest50 --lr-scheduler cos --epochs 300 --lr 0.01 --batch-size 16 --label-smoothing 0.1 --last-gamma --no-bn-wd --rectify --Download_folder Colour_Large_MFCC --CLASS1_LABELID 4 --CLASS2_LABELID 5 --crop-size 271 --FiveFold

python3 ResNeStGPU.py --dataset imagenet --model resnest50 --lr-scheduler cos --epochs 300 --lr 0.01 --batch-size 16 --label-smoothing 0.1 --last-gamma --no-bn-wd --rectify --Download_folder Colour_Large_STFT --CLASS1_LABELID 4 --CLASS2_LABELID 5 --crop-size 271 --FiveFold

python3 ResNeStGPU.py --dataset imagenet --model resnest101 --lr-scheduler cos --epochs 300 --lr 0.01 --batch-size 16 --label-smoothing 0.1 --last-gamma --no-bn-wd --rectify --Download_folder Colour_Large_MFCC --CLASS1_LABELID 4 --CLASS2_LABELID 5 --crop-size 271 --FiveFold

python3 ResNeStGPU.py --dataset imagenet --model resnest101 --lr-scheduler cos --epochs 300 --lr 0.01 --batch-size 16 --label-smoothing 0.1 --last-gamma --no-bn-wd --rectify --Download_folder Colour_Large_STFT --CLASS1_LABELID 4 --CLASS2_LABELID 5 --crop-size 271 --FiveFold

python3 ResNeStGPU.py --dataset imagenet --model resnest200 --lr-scheduler cos --epochs 300 --lr 0.01 --batch-size 16 --label-smoothing 0.1 --last-gamma --no-bn-wd --rectify --Download_folder Colour_Large_MFCC --CLASS1_LABELID 4 --CLASS2_LABELID 5 --crop-size 271 --FiveFold

python3 ResNeStGPU.py --dataset imagenet --model resnest200 --lr-scheduler cos --epochs 300 --lr 0.01 --batch-size 16 --label-smoothing 0.1 --last-gamma --no-bn-wd --rectify --Download_folder Colour_Large_STFT --CLASS1_LABELID 4 --CLASS2_LABELID 5 --crop-size 271 --FiveFold

python3 ResNeStGPU.py --dataset imagenet --model resnest269 --lr-scheduler cos --epochs 300 --lr 0.01 --batch-size 16 --label-smoothing 0.1 --last-gamma --no-bn-wd --rectify --Download_folder Colour_Large_MFCC --CLASS1_LABELID 4 --CLASS2_LABELID 5 --crop-size 271 --FiveFold

python3 ResNeStGPU.py --dataset imagenet --model resnest269 --lr-scheduler cos --epochs 300 --lr 0.01 --batch-size 16 --label-smoothing 0.1 --last-gamma --no-bn-wd --rectify --Download_folder Colour_Large_STFT --CLASS1_LABELID 4 --CLASS2_LABELID 5 --crop-size 271 --FiveFold

python3 ResNeStGPU.py --dataset imagenet --model resnest50 --lr-scheduler cos --epochs 300 --lr 0.01 --batch-size 16 --label-smoothing 0.1 --last-gamma --no-bn-wd --rectify --Download_folder Colour_Large_STFT --CLASS1_LABELID 4 --CLASS2_LABELID 5 --crop-size 271 --HoldOut

python3 ResNeStGPU.py --dataset imagenet --model resnest101 --lr-scheduler cos --epochs 300 --lr 0.01 --batch-size 16 --label-smoothing 0.1 --last-gamma --no-bn-wd --rectify --Download_folder Colour_Large_STFT --CLASS1_LABELID 4 --CLASS2_LABELID 5 --crop-size 271 --HoldOut

python3 ResNeStGPU.py --dataset imagenet --model resnest200 --lr-scheduler cos --epochs 300 --lr 0.01 --batch-size 16 --label-smoothing 0.1 --last-gamma --no-bn-wd --rectify --Download_folder Colour_Large_STFT --CLASS1_LABELID 4 --CLASS2_LABELID 5 --crop-size 271 --HoldOut

python3 ResNeStGPU.py --dataset imagenet --model resnest269 --lr-scheduler cos --epochs 300 --lr 0.01 --batch-size 16 --label-smoothing 0.1 --last-gamma --no-bn-wd --rectify --Download_folder Colour_Large_STFT --CLASS1_LABELID 4 --CLASS2_LABELID 5 --crop-size 271 --HoldOut

python3 Evaluation.py

python3 holdout_evalutation.py
docker build --network=host -t encoding .

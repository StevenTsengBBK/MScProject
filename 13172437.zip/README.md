# MScProject

Created by Yao-I Tseng

Please note that the code has been deposited in personal GitHub as well.

The repository: [Link]("https://github.com/StevenTsengBBK/MScProject")

## Dataset

The dataset can be downloaded from [UrbanSound8K](https://urbansounddataset.weebly.com/). Since size of dataset is too big, it original dataset is not included in this repository.

The detail of UrbanSound8K is described in the report done by Salamon et al.

J. Salamon, C. Jacoby and J. P. Bello, "A Dataset and Taxonomy for Urban Sound Research", 22nd ACM International Conference on Multimedia, Orlando USA, Nov. 2014.

```UrbanSound8K.csv``` is the detail of each audio data in UrbanSound8K dataset.

## Preprocessing

### Spectrogram

```Spectrogram.ipynb``` is a Jupyter file that generate some graphs for describing statisical information and spectrogram including MFCC and STFT.

The images will be stored in ```Colour_Large_MFCC``` and ```Colour_Large_STFT``` repositories.

### Numerical

```Classifier.ipynb``` is a Jupyter file that generate numerical features for Random Forest and SVM training.

The features will be stored in ```urbansound8k_features.csv```.

## ResNeSt Package

The ResNeSt package was originally created by [Hang Zhang](http://hangzh.com/).

In this project, some of the code requires customised to achieve the experiment. Especially ```imagenet.py``` which direct the programme for loading samples.

Please install the package with following command ```python setup.py install```.

As the programme expecting to run on GPUs, ensure there is GPU set up.

## Experiment

```execute.sh``` contains the command that triggers training all models, ResNeSt-50, ResNeSt-101, ResNeSt-200, and ResNeSt-269. At the same time, it also triggers holdout testing and evalutation.

The training process is located in ```ResNeStGPU.py``` and a ```ResNeSt_Data_Preparation.py``` file is used to prepare the samples that was initially alocated in 10 folds.

## Evalutation

```Evaluation.py``` is a file to evalutation the training process. It will generate the scores including accuracy of 5-fold cross-validation, sensitivity, specificity, AUROC and AUPRC. Moreover, it also generate the image is ROC curve and PR curves.

```holdout_evaluation.py``` is similar to ```Evaluation.py``` but it is used for holdout testing.